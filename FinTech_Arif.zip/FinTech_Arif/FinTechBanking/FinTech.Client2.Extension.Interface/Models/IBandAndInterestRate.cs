﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinTech.Client2.Extension.Interface.Models
{
    public interface IBandAndInterestRate
    {
        string BandType { get; set; }
        decimal MinBalance { get; set; }
        decimal InterestRate { get; set; }
    }
}
