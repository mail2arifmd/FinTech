﻿using FinTech.Client2.Extension.Interface.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinTech.Client2.Extension.Interface.Services
{
    public interface IBandAndInterestRatesService
    {
        List<IBandAndInterestRate> GetBandAndInterestRates();
    }
}
