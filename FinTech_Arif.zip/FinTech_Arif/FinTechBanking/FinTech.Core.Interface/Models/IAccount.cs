﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinTech.Core.Interface.Models
{
    public interface IAccount
    {
        string AccountNumber { get; set; }
        string AccountName { get; set; }
        decimal Balance { get; set; }
        string AccountType { get; set; }
    }
}
