﻿using System;
using FinTech.Core.DataAccess.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FinTech.Client2.Extension.CoreModelExtensions;
using FinTech.Client2.Extension.Services;
using FinTech.Client2.Extension.Interface.Models;
using System.Collections.Generic;

namespace FinTechBanking.Test
{
    [TestClass]
    public class InterestCalcTest
    {
        [TestMethod]
        public void Balance999_TestInterest_Percent001()
        {
            var acc = new Account { AccountNumber = "AccountNumber1", AccountName = "AccountName1", AccountType = "AccountType1", Balance = 999 };
            var expectedResult = acc.CalculateInterest();
            Assert.AreEqual(expectedResult, Math.Round(999 * 0.01m,2) );
        }

        [TestMethod]
        public void Balance1000_TestInterest_Percent0015()
        {
            var acc = new Account { AccountNumber = "AccountNumber1", AccountName = "AccountName1", AccountType = "AccountType1", Balance = 1000 };
            var expectedResult = acc.CalculateInterest();
            Assert.AreEqual(expectedResult, Math.Round(1000 * 0.015m,2) );
        }

        [TestMethod]
        public void Balance1001_TestInterest_Percent0015()
        {
            var acc = new Account { AccountNumber = "AccountNumber1", AccountName = "AccountName1", AccountType = "AccountType1", Balance = 1001 };
            var expectedResult = acc.CalculateInterest();
            Assert.AreEqual(expectedResult, Math.Round(1001 * 0.015m, 2));
        }

        [TestMethod]
        public void Balance4999_TestInterest_Percent0015()
        {
            var acc = new Account { AccountNumber = "AccountNumber1", AccountName = "AccountName1", AccountType = "AccountType1", Balance = 4999 };
            var expectedResult = acc.CalculateInterest();
            Assert.AreEqual(expectedResult, Math.Round(4999 * 0.015m,2) );
        }

        [TestMethod]
        public void Balance5000_TestInterest_Percent002()
        {
            var acc = new Account { AccountNumber = "AccountNumber1", AccountName = "AccountName1", AccountType = "AccountType1", Balance = 5000 };
            var expectedResult = acc.CalculateInterest();
            Assert.AreEqual(expectedResult, Math.Round(5000 * 0.02m,2) );
        }

        [TestMethod]
        public void Balance9999_TestInterest_Percent002()
        {
            var acc = new Account { AccountNumber = "AccountNumber1", AccountName = "AccountName1", AccountType = "AccountType1", Balance = 9999 };
            var expectedResult = acc.CalculateInterest();
            Assert.AreEqual(expectedResult, Math.Round(9999 *0.02m, 2));
        }

        [TestMethod]
        public void Balance10000_TestInterest_Percent0025()
        {
            var acc = new Account { AccountNumber = "AccountNumber1", AccountName = "AccountName1", AccountType = "AccountType1", Balance = 10000 };
            var expectedResult = acc.CalculateInterest();
            Assert.AreEqual(expectedResult, Math.Round(10000 *0.025m, 2));
        }

        [TestMethod]
        public void Balance49999_TestInterest_Percent0025()
        {
            var acc = new Account { AccountNumber = "AccountNumber1", AccountName = "AccountName1", AccountType = "AccountType1", Balance = 49999 };
            var expectedResult = acc.CalculateInterest();
            Assert.AreEqual(expectedResult, Math.Round(49999 *0.025m, 2));
        }

        [TestMethod]
        public void Balance50000_TestInterest_Percent003()
        {
            var acc = new Account { AccountNumber = "AccountNumber1", AccountName = "AccountName1", AccountType = "AccountType1", Balance = 50000 };
            var expectedResult = acc.CalculateInterest();
            Assert.AreEqual(expectedResult, Math.Round(50000 *0.03m, 2));
        }

        [TestMethod]
        public void Balance50001_TestInterest_Percent003()
        {
            var acc = new Account { AccountNumber = "AccountNumber1", AccountName = "AccountName1", AccountType = "AccountType1", Balance = 50001 };
            var expectedResult = acc.CalculateInterest();
            Assert.AreEqual(expectedResult, Math.Round(50001 *0.03m, 2));
        }
    }
}
