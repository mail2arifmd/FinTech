﻿using FinTech.Core.DataAccess.Models;
using FinTech.Core.Interface.Models;
using FinTech.Core.Interface.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinTech.Core.DataAccess.Services
{
    public class AccountService : IAccountService
    {
        public IEnumerable<IAccount> GetAllAccountDetails()
        {
            return new List<IAccount>{  new Account { AccountName="Account1", AccountNumber="TestAccount1", AccountType="Savings", Balance=999m },
                                        new Account { AccountName="Account2", AccountNumber="TestAccount2", AccountType="Savings", Balance=1000m },
                                        new Account { AccountName="Account3", AccountNumber="TestAccount3", AccountType="Savings", Balance=1001m },
                                        new Account { AccountName="Account4", AccountNumber="TestAccount4", AccountType="Savings", Balance=1999m },
                                        new Account { AccountName="Account5", AccountNumber="TestAccount5", AccountType="Savings", Balance=2000m },
                                        new Account { AccountName="Account6", AccountNumber="TestAccount6", AccountType="Savings", Balance=2001m },
                                        new Account { AccountName="Account7", AccountNumber="TestAccount7", AccountType="Savings", Balance=4999m },
                                        new Account { AccountName="Account8", AccountNumber="TestAccount8", AccountType="Savings", Balance=5000m },
                                        new Account { AccountName="Account9", AccountNumber="TestAccount9", AccountType="Savings", Balance=5001m },
                                        new Account { AccountName="Account10", AccountNumber="TestAccount10", AccountType="Savings", Balance=9999m },
                                        new Account { AccountName="Account11", AccountNumber="TestAccount11", AccountType="Savings", Balance=10000m },
                                        new Account { AccountName="Account12", AccountNumber="TestAccount12", AccountType="Savings", Balance=10001m },
                                        new Account { AccountName="Account13", AccountNumber="TestAccount13", AccountType="Savings", Balance=50000m },
                                        new Account { AccountName="Account14", AccountNumber="TestAccount14", AccountType="Savings", Balance=50001m }};
        }
    }
}
