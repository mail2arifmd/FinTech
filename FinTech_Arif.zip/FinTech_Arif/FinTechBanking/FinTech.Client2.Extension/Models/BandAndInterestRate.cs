﻿using FinTech.Client2.Extension.Interface.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinTech.Client2.Extension.Models
{
    public class BandAndInterestRate : IBandAndInterestRate
    {
        public string BandType { get; set; }
        public decimal MinBalance { get; set; }
        public decimal InterestRate { get; set; }
    }
}
