﻿using FinTech.Client2.Extension.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinTech.Client2.Extension
{
    public class ContextInterestStrategy
    {
        private static Dictionary<decimal, InterestStrategy> _strategies = new Dictionary<decimal, InterestStrategy>();

        static ContextInterestStrategy()
        {
            var bandsAndInterests = StrategyInterfaceFactory.GetBandAndInterestRates().OrderByDescending(i => i.MinBalance);

            foreach (var band in bandsAndInterests)
            {
                _strategies.Add(band.MinBalance, new InterestStrategy(band.BandType, band.InterestRate));
            }
        }

        public static decimal CalculateInterest(decimal amt)
        {
            foreach (var band in _strategies)
            {
                if (amt >= band.Key)
                    return _strategies[band.Key].CalculateInterest(amt);
                else
                    continue;
            }

            return 0.0m;
        }

    }
}
