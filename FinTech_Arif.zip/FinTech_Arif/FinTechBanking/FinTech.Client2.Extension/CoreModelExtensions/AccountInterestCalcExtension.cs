﻿using FinTech.Core.Interface.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinTech.Client2.Extension.CoreModelExtensions
{
    public static class AccountInterestCalcExtension
    {
        public static decimal CalculateInterest(this IAccount account)
        {
            return ContextInterestStrategy.CalculateInterest(account.Balance);
        }
    }
}
