﻿using FinTech.Client2.Extension.Interface.Models;
using FinTech.Client2.Extension.Interface.Services;
using FinTech.Client2.Extension.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinTech.Client2.Extension.Services
{
    public class BandAndInterestRatesService : IBandAndInterestRatesService
    {
        public List<IBandAndInterestRate> GetBandAndInterestRates()
        {
            return new List<IBandAndInterestRate> { new BandAndInterestRate { BandType="Tier1", MinBalance = 0, InterestRate = 0.01m },
                                                    new BandAndInterestRate { BandType="Tier2", MinBalance = 1000, InterestRate = 0.015m },
                                                    new BandAndInterestRate { BandType="Tier3", MinBalance = 5000, InterestRate = 0.02m },
                                                    new BandAndInterestRate { BandType="Tier4", MinBalance = 10000, InterestRate = 0.025m},
                                                    new BandAndInterestRate { BandType="Tier5", MinBalance = 50000, InterestRate = 0.03m }};
        }
    }
}
