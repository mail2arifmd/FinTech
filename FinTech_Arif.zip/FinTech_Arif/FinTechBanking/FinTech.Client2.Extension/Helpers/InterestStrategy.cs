﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinTech.Client2.Extension.Helpers
{
    public class InterestStrategy
    {
        private readonly decimal _interestRates = 0.0m;
        private readonly string _bandType = String.Empty;
        public InterestStrategy(string bandType, decimal interest)
        {
            _bandType = bandType;
            _interestRates = interest;
        }
        public decimal CalculateInterest(decimal amt)
        {
            return Math.Round(amt * _interestRates, 2);
        }
    }
}
