﻿using FinTech.Client2.Extension.Interface.Models;
using FinTech.Client2.Extension.Interface.Services;
using FinTech.Client2.Extension.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinTech.Client2.Extension
{
    public class StrategyInterfaceFactory
    {
        private static IBandAndInterestRatesService _service = new BandAndInterestRatesService();
        public static List<IBandAndInterestRate> GetBandAndInterestRates()
        {
            return _service.GetBandAndInterestRates();
        }
    }
}
